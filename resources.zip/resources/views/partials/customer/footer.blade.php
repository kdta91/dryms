<footer class="row">
    <!-- <div class="col-md-12"> -->
        <div class="col-md-6 text-center text-white p-4">
            &copy; 2019 DRYMSLISTINGS | Dumaguete City, Philippines, 6200
        </div>

        <div class="col-md-6 text-center text-white p-4">
            <a href="https://www.facebook.com/Dryms-Listings-104257300915983/" class="text-white" target="_blank"><i class="fab fa-facebook-f footer-social-icon pr-3"></i></a>
            <a href="" class="text-white"><i class="fab fa-instagram footer-social-icon pr-3"></i></a>
            <a href="" class="text-white"><i class="fab fa-tripadvisor footer-social-icon pr-3"></i></a>
        </div>
    <!-- </div> -->
</footer>