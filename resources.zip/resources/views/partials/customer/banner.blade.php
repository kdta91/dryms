<div id="home">
    <div id="homeBanner">

    </div>
</div>